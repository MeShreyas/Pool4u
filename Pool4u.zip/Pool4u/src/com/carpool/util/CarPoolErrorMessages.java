/**
 * 
 */
package com.carpool.util;

/**
 * @author Deepak
 *
 */
public class CarPoolErrorMessages {

	public static final String NO_ALERTS = "There are no alerts in the list!";
	public static final String NO_ERRORS = "Error Messages are not loaded in application cache.";
	public static final String NO_ALERT_TEMPLATE = "Alert template is not available";

}
