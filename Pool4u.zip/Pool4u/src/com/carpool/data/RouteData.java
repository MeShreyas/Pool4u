package com.carpool.data;

public class RouteData {
	private Long r;
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return r.toString();
	}

	public Long getR() {
		return r;
	}
}
