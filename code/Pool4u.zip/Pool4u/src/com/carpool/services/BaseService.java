/**
 * 
 */
package com.carpool.services;

/**
 * @author dhagedee
 *
 */
public abstract class BaseService {

}
